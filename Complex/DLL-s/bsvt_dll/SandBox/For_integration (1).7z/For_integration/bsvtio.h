#ifndef _bsvtio_h
#define _bsvtio_h 1
void Input(void);  /* Reading IO func */
void Output(void); /* Writing IO func */
#endif